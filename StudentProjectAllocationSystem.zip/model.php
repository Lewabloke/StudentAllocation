<?php
require 'db.php';