<?php
require 'init.php';
?>
<?php include 'head.php'; ?>
<body background="image/bg2.jpg">
   <div class="container start-container">
     <div class="col-md-6 title-text">
         <img src="image/polylogo.png" class="img-rounded img-responsive" width="100" height="100">
     	<h4>The Polytechnic, Ibadan</h4>
     	<h1>STUDENTS' PROJECT ALLOCATION & MANAGEMENT SYSTEM</h1>
     </div>
     <div class="col-md-4">
     	<?php include 'login_form.php'; ?>
     </div>
   </div>
<?php include 'footer.php'; ?>